<?php

namespace App\Http\Controllers;

use App\Models\Pereservasi;
use Illuminate\Http\Request;

class PereservasiController extends Controller
{
    public function index()
    {
        $data = Pereservasi::all();
        return view('pereservasi.index', compact('data'));
    }

    public function create()
    {
        return view('pereservasi.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate(([
            'nama' => 'required',
            'no_hp' => 'required',
            'nik' => 'required',
            'lama_tinggal' => 'required'
        ]));

        Pereservasi::create($data);
        return back()->with('message', 'data telah diisi');
    }

    public function show(Pereservasi $pereservasi)
    {
        return view('pereservasi.show', compact('pereservasi'));
    }

    public function edit(Pereservasi $pereservasi)
    {
        return view('pereservasi.edit', compact('pereservasi'));
    }

    public function update(Request $request, Pereservasi $pereservasi)
    {
        $attr = $request->validate(([
            'nama' => 'required',
            'no_hp' => 'required',
            'nik' => 'required',
            'lama_tinggal' => 'required'
        ]));

        $pereservasi->update($attr);
        return redirect()->route('pereservasi.index');
    }

    public function delete(Pereservasi $pereservasi)
    {
        $pereservasi->delete();
        return back();
    }

    // public function simpanData (Request $request){
    //     $nama = $request-> nama;
    //     $no_hp = $request-> no_hp;
    //     $nik = $request-> nik;
    //     $lama_tinggal = $request-> lama_tinggal;

    //     $data = new Pereservasi();
    //     $data->nama = $nama;
    //     $data->no_hp = $no_hp;
    //     $data->nik = $nik;
    //     $data->lama_tinggal = $lama_tinggal;
    //     $data->save();

    //     return redirect('pereservasi')->with('status', 'Data Disimpan!');
    // }

}
