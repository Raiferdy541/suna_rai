<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pereservasi extends Model
{
    use HasFactory;
    protected $table = 'pereservasi';
    protected $fillable = ['nama','no_hp','nik','lama_tinggal'];
}
