<?php

namespace Database\Pereservasi;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Pereservasi;

class PereservasiSeeder extends Pereservasi
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
