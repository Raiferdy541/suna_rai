@extends('layouts.app')
@section('SLOT')
<div class="w-full items-center justify-start bg-white">
    <div class="mx-auto w-full min-h-screen">

        <p class="mt-3">Silahkan isi data yang ingin anda ubah</p>
        <br><br/>

        <form action="{{route('pereservasi.update', ['pereservasi' => $pereservasi->id])}}" method="POST">
            @method('PUT')
            @csrf
            <div class="grid gap-6 sm:grid-cols-2">
                <div class="relative z-0">
                    <input type="text" name="nama" value={{$pereservasi->nama}}
                        class="peer block w-full appearance-none border-0 border-b border-gray-500 bg-transparent py-2.5 px-0 text-sm text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0"
                        placeholder=" " />
                    <label
                        class="absolute top-3 -z-10 origin-[0] -translate-y-6 scale-75 transform text-sm text-gray-500 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:left-0 peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-blue-600 peer-focus:dark:text-blue-500">Nama</label>
                        @error('nama')
                            <span class="text-red-500">{{ $message }}</span>
                        @enderror
                </div>
                <div class="relative z-0">
                    <input type="number" name="" value={{$pereservasi->no_hp}}
                        class="peer block w-full appearance-none border-0 border-b border-gray-500 bg-transparent py-2.5 px-0 text-sm text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0"
                        placeholder=" " />
                    <label
                        class="absolute top-3 -z-10 origin-[0] -translate-y-6 scale-75 transform text-sm text-gray-500 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:left-0 peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-blue-600 peer-focus:dark:text-blue-500">Nomor HP</label>
                        @error('no_hp')
                            <span class="text-red-500">{{ $message }}</span>
                        @enderror
                </div>
                <div class="relative z-0">
                    <input type="text" name="" value={{$pereservasi->nik}}
                        class="peer block w-full appearance-none border-0 border-b border-gray-500 bg-transparent py-2.5 px-0 text-sm text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0"
                        placeholder=" " />
                    <label
                        class="absolute top-3 -z-10 origin-[0] -translate-y-6 scale-75 transform text-sm text-gray-500 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:left-0 peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-blue-600 peer-focus:dark:text-blue-500">NIK</label>
                        @error('nik')
                            <span class="text-red-500">{{ $message }}</span>
                        @enderror
                </div>
                <div class="relative z-0">
                    <input type="text" name="" value={{$pereservasi->lama_tinggal}}
                        class="peer block w-full appearance-none border-0 border-b border-gray-500 bg-transparent py-2.5 px-0 text-sm text-gray-900 focus:border-blue-600 focus:outline-none focus:ring-0"
                        placeholder=" " />
                    <label
                        class="absolute top-3 -z-10 origin-[0] -translate-y-6 scale-75 transform text-sm text-gray-500 duration-300 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:left-0 peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-blue-600 peer-focus:dark:text-blue-500">Lama Tinggal</label>
                        @error('lama_tinggal')
                            <span class="text-red-500">{{ $message }}</span>
                        @enderror
                </div>

            </div>
            <button type="submit" class="mt-5 rounded-md bg-black px-10 py-2 text-white">Update</button>
        </form>
    </div>
</div>
@endsection
