<x-app-layout>
    <x-slot name="title">
        Profile
    </x-slot>

    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Profile') }}
        </h2>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        Profile Page
                    </div>
                </div>
            </div>
        </div>

        <div class="py-8">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h4>Seorang mahasiswa yang antusias dengan teknologi</h4>
                        <br/>
                        <h4> Nama saya Raihan Ferdyanza ,NPM kuliah saya 2015061085. Program Studi yang saya pelajari yaitu Teknik Informatika.Jurusan saya yaitu Teknik Elektro . Saya kuliah di Universitas Lampung .Alamat tempat saya tinggal yaitu Jalan Dr.Susilo Gg.Kenanga 2 No.12 Bandarlampung .Saya berumur 20 Tahun .Saya Lahir pada tanggal 28 Juni 2002 di Bandarlampung </h4>
                    </div>
                    <div>
                        <img src="https://drive.google.com/uc?id=1k9b7pGjxlLWLiEoyqAexLlB5o99oQog6" alt="gambar_raihan">
                    </div>
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h4>Saya berantusias menjadi seorang developer yang terkenal.</h4>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    Home Page
                </div>
            </div>
        </div>
    </div>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4>Rumah Susun Sederhana Sewa</h4>
                    <br/>
                    <h4>Rusunawa merupakan singkatan dari rumah susun sederhana sewa. Rusunawa adalah bangunan bertingkat yang dibangun oleh pemerintah dalam satu lingkungan tempat hunian dan disewakan kepada keluarga kurang mampu dengan cara pembayaran per bulan. Rusunawa merupakan satuan-satuan hunian yang digunakan secara terpisah, status penguasaanya sewa, dan fungsi utama sebagai hunian</h4>
                </div>
                <div>
                    <img src="https://minanews.net/wp-content/uploads/2019/06/17-35-19-2pempr20190625163407.jpg" alt="gambar_rusunawa">
                </div>
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4>Rusunawa dibangun oleh pemerintah dengan menggunakan dana Anggaran  Pendapatan dan Belanja Negara atau Daerah. Biasanya pemerintah daerah bekerja sama dengan Kementerian Perumahan Rakyat. Pembangunan dari Rusunawa bertujuan untuk menyediakan rumah layak huni bagi seluruh keluarga Indonesia, khususnya MBR (Masyarakat Berpenghasilan Rendah) yang belum mempunyai kemampuan untuk memenuhi kebutuhan rumahnya melalui kepemilikan.</h4>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
