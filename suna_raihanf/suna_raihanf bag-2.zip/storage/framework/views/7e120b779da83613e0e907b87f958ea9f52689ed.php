<?php $__env->startSection('content'); ?>
    <h1>Perkuliahan</h1>
    <?php $date = date ('y-m-d'); ?>
    <?php if($date=='2022-10-17'): ?>
        <?php echo e('hari ini kuliah WF'); ?>

    <?php else: ?>
        <?php echo e('hari ini tidak kuliah WF'); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('belajar-template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_framework\resources\views/belajar-template/index.blade.php ENDPATH**/ ?>