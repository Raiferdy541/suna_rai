<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Profile
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('About')); ?>

        </h2>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        About Page
                    </div>
                </div>
            </div>
        </div>

        <div class="py-8">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h4>Panduan Reservasi Rusunawa</h4>
                        <br/>
                        <h4></h4>
                    </div>
                    <div class="ml-11">
                        <img src="https://www.cmpenalba.org/wp-content/uploads/2021/07/P6230002-1024x768.jpg" alt="gambar_orangrusun" >
                    </div>
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h4>Dalam melakukan reservasi rusunawa, Calon penginap reservasi melakukan permintaan keinginan untuk mereservasi kamar pada admin, lalu admin akan menginputkan sesuai dengan data yang diberikan, lalu admin akan mengonfirmasi data-data lebih lanjut, serta memberikan persetujuan kamar. </h4>
                        <br>
                        <h4>Rusunawa dibangun oleh pemerintah dengan menggunakan dana Anggaran  Pendapatan dan Belanja Negara atau Daerah. Biasanya pemerintah daerah bekerja sama dengan Kementerian Perumahan Rakyat. Pembangunan dari Rusunawa bertujuan untuk menyediakan rumah layak huni bagi seluruh keluarga Indonesia, khususnya MBR (Masyarakat Berpenghasilan Rendah) yang belum mempunyai kemampuan untuk memenuhi kebutuhan rumahnya melalui kepemilikan.</h4>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    Home Page
                </div>
            </div>
        </div>
    </div>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4>Rumah Susun Sederhana Sewa</h4>
                    <br/>
                    <h4>Rusunawa merupakan singkatan dari rumah susun sederhana sewa. Rusunawa adalah bangunan bertingkat yang dibangun oleh pemerintah dalam satu lingkungan tempat hunian dan disewakan kepada keluarga kurang mampu dengan cara pembayaran per bulan. Rusunawa merupakan satuan-satuan hunian yang digunakan secara terpisah, status penguasaanya sewa, dan fungsi utama sebagai hunian</h4>
                </div>
                <div>
                    <img src="https://minanews.net/wp-content/uploads/2019/06/17-35-19-2pempr20190625163407.jpg" alt="gambar_rusunawa">
                </div>
                <div class="p-6 bg-white border-b border-gray-200">
                    <h4>Rusunawa dibangun oleh pemerintah dengan menggunakan dana Anggaran  Pendapatan dan Belanja Negara atau Daerah. Biasanya pemerintah daerah bekerja sama dengan Kementerian Perumahan Rakyat. Pembangunan dari Rusunawa bertujuan untuk menyediakan rumah layak huni bagi seluruh keluarga Indonesia, khususnya MBR (Masyarakat Berpenghasilan Rendah) yang belum mempunyai kemampuan untuk memenuhi kebutuhan rumahnya melalui kepemilikan.</h4>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\suna_raihanf\resources\views/pereservasi/about.blade.php ENDPATH**/ ?>