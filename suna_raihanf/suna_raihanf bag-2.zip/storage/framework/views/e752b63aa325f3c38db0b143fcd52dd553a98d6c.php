<?php $__env->startSection('content'); ?>
    <h1>Perkuliahan</h1>
    <?php $date = date ('y-m-d'); ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setiap_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($setiap_data->nama_mhs); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('belajar-template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_framework\resources\views/mahasiswa/mahasiswa.blade.php ENDPATH**/ ?>