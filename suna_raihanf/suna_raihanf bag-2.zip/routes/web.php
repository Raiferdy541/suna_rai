<?php

use App\Http\Controllers\PereservasiController;
use App\Http\Controllers\MahasiswaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

require __DIR__.'/auth.php';

Route::get('/pereservasi/about', function () {
    return view('pereservasi.about');
});

Route::get('/profile', function () {
    return view('profile');
});

Route::get('/pereservasi/contact', function () {
    return view('pereservasi.contact');
});

Route::get('/mahasiswa/index', [MahasiswaController::class, 'index'])->name('mahasiswa.index');

Route::get('/pereservasi', [PereservasiController::class, 'create'])->name('pereservasi.create');
Route::post('/pereservasi/store', [PereservasiController::class, 'store'])->name('pereservasi.store');
Route::get('/pereservasi/index', [PereservasiController::class, 'index'])->name('pereservasi.index');
Route::get('/pereservasi/{pereservasi}', [PereservasiController::class, 'show'])->name('pereservasi.show');
Route::get('/pereservasi/edit/{pereservasi}', [PereservasiController::class, 'edit'])->name('pereservasi.edit');
Route::put('/update/pereservasi/show/{pereservasi}', [PereservasiController::class, 'update'])->name('pereservasi.update');
Route::delete('/delete/pereservasi/show/{pereservasi}', [PereservasiController::class, 'delete'])->name('pereservasi.delete');

//Route::post('/pereservasi/store', [PereservasiController::class, 'simpanData']) -> name('pereservasi.store');//
